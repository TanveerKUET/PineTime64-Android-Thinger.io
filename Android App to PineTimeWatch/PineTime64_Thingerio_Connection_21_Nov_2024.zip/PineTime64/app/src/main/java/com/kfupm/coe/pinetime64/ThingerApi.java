package com.kfupm.coe.pinetime64;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ThingerApi {
    @POST("users/TanveerKFUPM/devices/pinedroid24/callback/data?authorization=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJEZXZpY2VDYWxsYmFja19waW5lZHJvaWQyNCIsInN2ciI6ImV1LWNlbnRyYWwuYXdzLnRoaW5nZXIuaW8iLCJ1c3IiOiJUYW52ZWVyS0ZVUE0ifQ.41U4PiCCqxpOFAKw7hBTNkeu4cfimeYelyurm5sKBBY")

    Call<Void> postData(
            //@Header("Authorization") String token,
            @Body DataPayload data
    );
}



