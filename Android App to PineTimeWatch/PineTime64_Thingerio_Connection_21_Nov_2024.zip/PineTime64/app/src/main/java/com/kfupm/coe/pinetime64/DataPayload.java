package com.kfupm.coe.pinetime64;

public class DataPayload {
    private String heartbeatrate;

    public DataPayload(String heartbeatrate) {
        this.heartbeatrate = heartbeatrate;
    }

    // Getters and setters (if needed)
}

