package com.kfupm.coe.pinetime64;

import android.app.Activity;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.database.Cursor;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ViewDataActivity extends Activity {

    DatabaseHelper dbHelper;
    ListView lvData;
    EditText etStartDate, etEndDate;
    Button btnSearch, btnExportCSV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_data);

        dbHelper = new DatabaseHelper(this);

        lvData = findViewById(R.id.lv_data);
        etStartDate = findViewById(R.id.et_start_date);
        etEndDate = findViewById(R.id.et_end_date);
        btnSearch = findViewById(R.id.btn_search);
        //btnExportCSV = findViewById(R.id.btn_export_csv);

        // Load all data initially
        loadAllData();

        btnSearch.setOnClickListener(v -> {
            String startDate = etStartDate.getText().toString();
            String endDate = etEndDate.getText().toString();

            if (startDate.isEmpty() || endDate.isEmpty()) {
                Toast.makeText(this, "Please enter both start and end dates", Toast.LENGTH_SHORT).show();
                return;
            }

            loadFilteredData(startDate, endDate);
        });

        //btnExportCSV.setOnClickListener(v -> exportDataToCSV());
    }

    private void loadAllData() {
        Cursor cursor = dbHelper.getAllData();
        bindDataToListView(cursor);
    }

    private void loadFilteredData(String startDate, String endDate) {
        Cursor cursor = dbHelper.getData(startDate, endDate);
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No data found for the selected dates", Toast.LENGTH_SHORT).show();
        }
        bindDataToListView(cursor);
    }

    private void bindDataToListView(Cursor cursor) {
        String[] fromColumns = new String[]{"_id","Name", "HeartRate", "DateTime"};
        int[] toViews = new int[]{
                R.id.tv_id,
                R.id.tv_name,
                R.id.tv_heart_rate,
                R.id.tv_date_time
        };

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,
                R.layout.list_heartbeat_data_item,  // Custom layout for list items
                cursor,
                fromColumns,
                toViews,
                0
        );
        lvData.setAdapter(adapter);
    }



    private void exportDataToCSV() {
        Cursor cursor = dbHelper.getAllData();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No data to export", Toast.LENGTH_SHORT).show();
            return;
        }

        File downloadsFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!downloadsFolder.exists()) {
            downloadsFolder.mkdirs(); // Create the folder if it doesn't exist
        }

        File csvFile = new File(downloadsFolder, "HeartRateData.csv");

        try (FileWriter writer = new FileWriter(csvFile)) {
            writer.append("ID,Name,HeartRate,DateTime\n");

            while (cursor.moveToNext()) {
                writer.append(cursor.getString(0)) // ID
                        .append(",")
                        .append(cursor.getString(1)) // Name
                        .append(",")
                        .append(cursor.getString(2)) // HeartRate
                        .append(",")
                        .append(cursor.getString(3)) // DateTime
                        .append("\n");
            }

            Toast.makeText(this, "Data exported to: " + csvFile.getAbsolutePath(), Toast.LENGTH_LONG).show();

        } catch (IOException e) {
            Toast.makeText(this, "Failed to export data: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}