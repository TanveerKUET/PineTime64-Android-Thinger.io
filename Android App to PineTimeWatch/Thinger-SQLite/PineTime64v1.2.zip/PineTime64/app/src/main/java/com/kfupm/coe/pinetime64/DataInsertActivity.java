package com.kfupm.coe.pinetime64;

import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DataInsertActivity extends AppCompatActivity{

    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_insert);

        EditText etName = findViewById(R.id.et_name);
        EditText etHeartRate = findViewById(R.id.et_heart_rate);
        Button btnSave = findViewById(R.id.btn_save);
        Button btnViewData = findViewById(R.id.btn_view_data);

        dbHelper = new DatabaseHelper(this);

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String heartRateStr = etHeartRate.getText().toString();

            if (name.isEmpty() || heartRateStr.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int heartRate = Integer.parseInt(heartRateStr);


            SimpleDateFormat sdf = new SimpleDateFormat("dd:MM:yyyy HH:mm:ss", Locale.getDefault());

            // Get the current date and time
            String dateTime  = sdf.format(new Date());

            // Print the formatted date and time
            Log.e("Current Date and Time: ", dateTime);

            if (dbHelper.insertData(name, heartRate, dateTime)) {
                Toast.makeText(this, "Data Saved", Toast.LENGTH_SHORT).show();
                Log.e("DATA INSERT"," SUCCESS");
            } else {
                Toast.makeText(this, "Failed to Save Data", Toast.LENGTH_SHORT).show();
                Log.e("DATA INSERT"," SUCCESS");
            }
        });

        btnViewData.setOnClickListener(v -> {
            Intent intent = new Intent(this, ViewDataActivity.class);
            startActivity(intent);
        });
    }
}